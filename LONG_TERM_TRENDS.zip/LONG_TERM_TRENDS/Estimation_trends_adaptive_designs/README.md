# Estimation_trends_adaptive_designs
This folder contains WinBUGS and R code for reproducing results in the manuscript titled "Assessing the ability of adaptive designs to capture trends in hard coral cover”. 
