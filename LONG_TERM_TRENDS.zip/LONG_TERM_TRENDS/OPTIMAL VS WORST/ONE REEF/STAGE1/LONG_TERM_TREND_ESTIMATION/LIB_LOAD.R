library("matrixcalc",lib.loc="/home/n9592385/Year_2/paper1_code/intel_pack")#is.singular
library("Matrix",lib.loc="/home/n9592385/Year_2/paper1_code/intel_pack")
library("mvtnorm",lib.loc="/home/n9592385/Year_2/paper1_code/intel_pack")
library("sp",lib.loc="/home/n9592385/Year_2/paper1_code/intel_pack")
library("corpcor",lib.loc="/home/n9592385/Year_2/paper1_code/intel_pack")
library("fastDummies",lib.loc="/home/n9592385/Year_2/paper1_code/intel_pack") #create design matrix for random effecst
library(gtools)