##################################################
## Project: PhD Study 2
## Script purpose:Utility evaluation when dropping one reef at Stage 1 for optimal vs worst design comparision
## Date: 15/01/2020
## Author: A.W.L.PUBUDU THILAN
## Description: This is the same as utility evaluation under dropping one reefs. 
#As described in the manuscript, there are ten possible designs. 
# This is for evaluating utilities for the design choice 1. (i.e. DESIGN_INDEX<-1)
#To evaluate designs for the other designs, you have to change DESIGN_INDEX
# Instead of the design that resulted in the heighst mean expected utility value, we choose the design that resulsted in the lowest 
# mean expected utility value. Utility evaluation would be different to REEF DROPPING SCENARIO (i.e one reef) starting from STAGE2

##################################################

source('LIB_LOAD.R') #LOAD LIBRARIES
source('Log_likeF.R') # LIKELIHOOD RELATED TO FIXED EFFECT ESTIMATION
source('Log_like2.R') # LIKELIHOOD RELATED TO RANDOM EFFECT ESTIMATION
source('log_posterior2.R')
source('Laplace_approx2.R') # RANDOM EFFECT ESTIMATION
source('log_posteriorF.R') # COMBINDED LIKELIHOOD and PRIOR
source('LP_Approximation.R')  # FIXED EFFECT ESTIMATION
source('covariate_generate.R') # SIMULATE COVARIATE DATA
source('trace.R') # CALCULATE TRACE REALTED KLD
source('stdize.R') #STANDARDIZED COVARIATES


seed.val<-20
set.seed(seed.val)

#@@@@@@@@@@@@@@INPUT: PARAMETERS@@@@@@@@@@@@@@@@@@@@@
DESIGN_INDEX<-1#@@@@@@@@@@@@@@@@@@@@INPUT: CHANGE DESIGN INDEX HERE
SAMPLING_YEAR<-2003#@@@@@@@@@@@@@@@@@@@@INPUT: CHANGE SAMPLYING YEAR HERE
E<-10# independent evaluations
B<-200 #Monte carlo intergration
Total_EB<-E*B
no_samples<-10000

asite<-30
nsite<-27 #@@@@@@@@@@@@@@@@@@@@INPUT:SPECIFY NUMBER OF SITES
nobs<-5 #per site
leny<-nsite*nobs # Total number of samples for next sampling year


set.seed(seed.val)
rand_uni<-matrix(runif(leny*Total_EB),ncol=Total_EB,nrow =leny ) #For deterministic simulation of Y

ST<-asite*Total_EB
set.seed(seed.val)
rand_uni_Cov<-runif(4*ST)
CoTSr<<-matrix(rand_uni_Cov[1:ST],ncol=Total_EB,nrow =asite ) #For deterministic simulation of CoTS
STORMr<<-matrix(rand_uni_Cov[(ST+1):(2*ST)],ncol=Total_EB,nrow =asite)
BLEACHr<<-matrix(rand_uni_Cov[(2*ST+1):(3*ST)],ncol=Total_EB,nrow =asite)
HERBr<<-matrix(rand_uni_Cov[(3*ST+1):(4*ST)],ncol=Total_EB,nrow =asite )

GBR_data<-read.csv("GBR_ltmp_Get_Covariate.csv") #@@@@@@@@@@@@@@@@@@@@INPUT: DATA
GBR_data<-GBR_data[GBR_data$A_SECTOR=='CA',] 
GBR_data<-GBR_data[GBR_data$REPORT_YEAR<=SAMPLING_YEAR,] #@@@@@@@@@@@@@@@@@@@@INPUT:SPECIFY SAMPLING YEAR
nreefs<-length(unique(GBR_data$REEF_ID))#Recode REEF_IDs


######################### START:SIMULATE FIXED EFFECTS ##################################
prior_fixed_effects<-read.csv("PRIOR_FIXED_EFFECTS_2002.csv") #@@@@@@@@@@@@@@@@@@@@INPUT:FIXED EFFECTS MEAN & SD
mu_prior_fixed<-as.vector(unlist(prior_fixed_effects[1]))
Sigma_priorb_fixed<-as.vector(unlist(prior_fixed_effects[2]^2))
Sigma_prior_fixed <-diag(Sigma_priorb_fixed)

iSigma_prior <- solve(Sigma_prior_fixed)
dSigma_prior <- det(Sigma_prior_fixed)
num_par <- length(mu_prior_fixed)

theta_sim_fixed <- matrix(0,nrow=Total_EB,ncol=length(mu_prior_fixed))
set.seed(seed.val)
for (j in 1:length(mu_prior_fixed)){
  theta_sim_fixed[,j] <-rnorm(Total_EB,mu_prior_fixed[j],sqrt(Sigma_priorb_fixed[j]))
}

theta_sim_fixed <- data.frame(theta_sim_fixed)
theta_sim_fixed0 <- as.data.frame(sweep(theta_sim_fixed,2,colMeans(theta_sim_fixed),"-"))  # shift the mean 
C <- chol(nearPD(cov(theta_sim_fixed0))$mat)
set.seed(seed.val)
SN <- matrix(rnorm((Total_EB) * ncol(theta_sim_fixed)), ncol(theta_sim_fixed))#standard normals
X <- t(C) %*% SN
theta_mul_fixed <- data.frame(as.matrix(t(X)))
names(theta_mul_fixed) <- names(theta_sim_fixed)
theta_mul_fixed <- as.data.frame(sweep(theta_mul_fixed,2,colMeans(theta_sim_fixed),"+")) 
theta_sim_all_fixed<-as.matrix(theta_mul_fixed)
######################### END:SIMULATE FIXED EFFECTS ##################################

######################### START:SIMULATE RANDOM EFFECTS ##################################
random_mean<-t(as.vector(read.csv("RANDOM_MEAN_2002.csv"))) 
random_sigma_post<-as.matrix(read.csv("RANDOM_SIGMA_POST_2002.csv"))
set.seed(seed.val)
theta_sim_all_random <- round(rmvnorm(Total_EB, random_mean, random_sigma_post),digits = 4)

kld.utility<-function(d,sim_fixed,sim_random,indexB){
  kld.post.val=matrix(0,B)
 
  for (j in 1:B){
  Covaiate_data<-Get_Covariate(d,seed.val,j*indexB) 
  nreefs_rem<-length(unique(Covaiate_data$REEF_ID))
  NEW_REEF_ID<-unique(Covaiate_data$REEF_ID)#needs to change here when dropping reefs
  Ir=Covaiate_data[,7]
  Ir_design <<- as.matrix(dummy_cols(Ir)[,c(2:(nreefs_rem+1))])
  ran_design_spatial <<- as.matrix(dummy_cols(Covaiate_data[,1])[,c(2:(nsite+1))])#Create a design matrix for sites
  
  WQ<-rep(0,nreefs_rem) 
  CoTS <<- ifelse(Covaiate_data[,2]-mean(Covaiate_data[,2])<0.00001,Covaiate_data[,2],stdize(Covaiate_data[,2]))
  BLEACH<<-ifelse(Covaiate_data[,4]-mean(Covaiate_data[,4])<0.00001,Covaiate_data[,4],stdize(Covaiate_data[,4]))
  HERB <<- ifelse(Covaiate_data[,5]-mean(Covaiate_data[,5])<0.00001,Covaiate_data[,5],stdize(Covaiate_data[,5]))
  for(i in 1:nreefs_rem){
    WQ[i]<-Covaiate_data[Covaiate_data$REEF_ID==NEW_REEF_ID[i],]$WQ[1]
  }
  WQ<<-WQ
  
  ZONE<<-Covaiate_data[,8]
  HC1<<-round(Covaiate_data[,12]) +1
  
  fixed_eff<-sim_fixed[j,]
  sim_random1<-sim_random[j,]
  
  r <- fixed_eff[1]
  a <- fixed_eff[2]
  reef_sd <-exp(fixed_eff[3])
  
  g2 <- fixed_eff[4]
  g7 <- fixed_eff[5]
  g9 <- fixed_eff[6]
  g13 <- fixed_eff[7]

  zb<-matrix(sim_random1[NEW_REEF_ID],ncol=1)
  
  mu<-(1 - a)*log(HC1)+g2*CoTS+g7*HERB+g9*CoTS*(Ir_design%*%matrix(WQ))+g13*CoTS*ZONE+Ir_design%*%zb
  p<-as.matrix(exp(mu)/100)
  if((any(p>1)==TRUE)){
    index=which(p>1)
    p[index,]=rep(0.9999,length(index))
  }
  
  set.seed(seed.val)
  Y<-qbinom(rand_uni[,j],100,p)
  
  para<-fixed_eff
  para2<-zb
  mu_pr<<-mu_prior_fixed
  sigma_pr<<-as.vector(unlist(prior_fixed_effects[2]))
  
  kld_out=LP_Approximation(log_postF,Y,para,para2)
  
  if(kld_out==0) {kld_out=NA}
  else{kld_out=kld_out}
  
  print(kld_out)
  kld.post.val[j]=kld_out
  }
  return(kld.post.val)
}

#########################FIND SITES IN THE DESIGN#############################
all_design<-read.csv("all_design_one_reef_dropped.csv",header = T)#@@@@@@@@@@@@@@@@@@@@INPUT:DESIGN MATRIX
design_com=all_design[,DESIGN_INDEX] #@@@@@@@@@@@@@@@@@@@@INPUT: CHOOSE DESIGN (REEF) TO EVALUATE

new_design_tem<-list()
for (i in 1:9)
{
  t=design_com[i]
  new_design_tem[[i]]<-unique(GBR_data$SITE_INDEX[GBR_data$REEF_ID==t])
}
new_design=do.call(rbind,new_design_tem)
d=matrix(new_design,ncol = nsite,nrow=1)
#########################@@@@@@@@@@@@@@@@@@@@@@@@#############################

################################HPC-INDEX###########################
indexB <- Sys.getenv("PBS_ARRAY_INDEX")
n_ind <- as.numeric(indexB)

indexB <- (1+(n_ind-1)*B):(n_ind*B)
indexB <- indexB[indexB<=E*B]

################################HPC-INDEX###########################

udy=mean(kld.utility(d,theta_sim_all_fixed[indexB,],theta_sim_all_random[indexB,],n_ind),na.rm=T)
udy

v_ut<-"design"
v_ut <- paste(v_ut,DESIGN_INDEX,sep="")
v_ut <- paste(v_ut,"_",sep="")
v_ut <- paste(v_ut,n_ind,sep="")
v_fileName <- paste(v_ut,"RData",sep=".")
save(list= c("udy"),file = v_fileName)











