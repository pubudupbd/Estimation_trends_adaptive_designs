library("MASS", lib.loc="C:/Program Files/R/R-3.5.1/library")# fitdistr function

# Function to standardize covariates
# (See Scaling regression inputs by dividing by two standard deviations for more details)
stdize=function(x){
  mean=mean(x)
  sd=sd(x)
  return((x-mean)/(2*sd)) 
}

GBR_data<-read.csv("GBR_ltmp.csv")
GBR_data<-GBR_data[GBR_data$A_SECTOR=='CA',] 
GBR_data<-GBR_data[GBR_data$REPORT_YEAR<2003,] 

# Get rid of missing years

# replace -999 with NA
GBR_data$HC<-ifelse(GBR_data$HC==-999,NA,GBR_data$HC)
GBR_data$HC_1<-ifelse(GBR_data$HC_1==-999,NA,GBR_data$HC_1)

GBR_data=GBR_data[is.na(GBR_data$HC)==F,]
GBR_data=GBR_data[is.na(GBR_data$HC_1)==F,]
n<-dim(GBR_data)[1] #total number of observations


#Reeef numbers are needed to be recoded
GBR_data$REEF_ID<-as.numeric(GBR_data$REEF_ID)
nreefs<-length(unique(GBR_data$REEF_ID))

for(i in 1:nreefs){
  GBR_data$REEF_ID=ifelse(GBR_data$REEF_ID==8+i,i,GBR_data$REEF_ID)
}

table(GBR_data$REEF_ID)


# Substitute numbers for Cluster codes
GBR_data$CLUSTER=as.numeric(GBR_data$CLUSTER)
table(GBR_data$CLUSTER)


#Create index for sites
GBR_data$SITE_INDEX<-as.numeric(factor(paste(GBR_data$REEF_ID,GBR_data$SITE_NO,sep="_"))) #create index for sites
table(GBR_data$SITE_INDEX)
nsite<-length(unique(GBR_data$SITE_INDEX))


dis_mat<-matrix(0,nsite,13)
for(i in 1:nsite)
{
  #COTS
  COTS1<-GBR_data$C[GBR_data$SITE_INDEX==i]
  COTS_nozero<-COTS1[COTS1!=0]
  zero_COTS_prob<-(length(COTS1)-length(COTS_nozero))/length(COTS1)
  dis_mat[i,1]<-zero_COTS_prob #COTS=0, probability
  if(zero_COTS_prob!=1){
    COTS_nozero_Log<-log(COTS_nozero)
    Cots_dis<-fitdistr( COTS_nozero_Log, "normal")
    dis_mat[i,2]<-Cots_dis$estimate[1]
    dis_mat[i,3]<-Cots_dis$estimate[2]
  }
  #Cyclone=STORM
  STORM1<-GBR_data$S[GBR_data$SITE_INDEX==i]
  STORM_nozero<-STORM1[STORM1!=0]
  zero_STORM_prob<-(length(STORM1)-length(STORM_nozero))/length(STORM1)
  dis_mat[i,4]<-zero_STORM_prob #STORM=0, probability
  
  if(zero_STORM_prob!=1){
    STORM_nozero_Log<-log(STORM_nozero)
    STORM_dis<-fitdistr( STORM_nozero_Log, "normal")
    dis_mat[i,5]<-STORM_dis$estimate[1]
    dis_mat[i,6]<-STORM_dis$estimate[2]
  }
  
  #Bleaching
  BLEACH1<-GBR_data$B[GBR_data$SITE_INDEX==i]
  BLEACH_nozero<-BLEACH1[BLEACH1!=0]
  zero_BLEACH_prob<-(length(BLEACH1)-length(BLEACH_nozero))/length(BLEACH1)
  dis_mat[i,7]<-zero_BLEACH_prob #STORM=0, probability
  
  if(zero_BLEACH_prob!=1){
    BLEACH_nozero_Log<-log(BLEACH_nozero)
    BLEACH_dis<-fitdistr( BLEACH_nozero_Log, "normal")
    dis_mat[i,8]<-BLEACH_dis$estimate[1]
    dis_mat[i,9]<-BLEACH_dis$estimate[2]
  }
  
  #HERB
  HERB1<-GBR_data$HERB[GBR_data$SITE_INDEX==i]
  HERB_nozero<-HERB1[HERB1!=0]
  zero_HERB_prob<-(length(HERB1)-length(HERB_nozero))/length(HERB1)
  dis_mat[i,10]<-zero_HERB_prob #HERB=0, probability
  
  if(zero_HERB_prob!=1){
    HERB_nozero_Log<-log(HERB_nozero)
    HERB_dis<-fitdistr(HERB_nozero_Log, "normal")
    dis_mat[i,11]<-HERB_dis$estimate[1]
    dis_mat[i,12]<-HERB_dis$estimate[2]
  }
  
  #WQ=PFsum
  WQ1<-GBR_data$PFsum[GBR_data$SITE_INDEX==i]
 
  dis_mat[i,13]<-log(WQ1)[1] #WQ is a constant for a given dite
  
}

dis_mat_site=data.frame(SITE_INDEX=seq(1,nsite,1))
dis_mat=cbind(dis_mat_site,data.frame(dis_mat))


write.csv(dis_mat,"distribution_mat.csv")

