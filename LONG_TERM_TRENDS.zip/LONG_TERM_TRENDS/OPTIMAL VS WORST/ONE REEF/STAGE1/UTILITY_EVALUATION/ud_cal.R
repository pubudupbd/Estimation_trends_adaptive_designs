udy_val<-matrix(rep(0,1200),nrow = 1200, ncol = 1)

for (i in 1065:1200)
{

  v_ut <- "design1"
  v_ut <- paste(v_ut,i,sep="_")
  v_fileName <- paste(v_ut,"RData",sep=".")
  print(v_fileName)
  load(v_fileName)
  udy_val[i]<-udy
}
  
write.csv(udy_val,"udy_val.csv")


