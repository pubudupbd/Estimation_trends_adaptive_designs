##################################################
## Project: PhD Study 2
## Script purpose: Gompertz model posterior predictives
## Date: 15/01/2020
## Author: A.W.L.PUBUDU THILAN
## Description: This evaluates posterior predictives of the Gompertz model at the sampling year of 2002
##################################################
library("TeachingDemos")

predict<-matrix(rep(0,n*dim(para_sim)[1]),ncol=dim(para_sim)[1])
for (i in 1:dim(para_sim)[1])
{
  fixed_eff=para_sim[i,]
  reef_rand=random_sim[i,]
  
  r <- fixed_eff[1]
  a <- fixed_eff[2]
  
  g2 <- fixed_eff[4]
  g7 <- fixed_eff[5]
  g9 <- fixed_eff[6]
  g13 <- fixed_eff[7]
  
  mu <-(1 - a)*log(HC1)+g2*CoTS+g7*HERB+g9*CoTS*(Ir_design %*%matrix(WQ))+g13*CoTS*ZONE+Ir_design %*% reef_rand
  p=as.matrix(exp(mu)/100)
  predict[,i]=rbinom(n,100,p)
}


data_predict<-data.frame(cbind(GBR_data,predict))
time_unique<-sort(unique(data_predict$REPORT_YEAR))
time_index<-seq(1,length(unique(data_predict$REPORT_YEAR)))
N.time=length(time_index)

posterior.median<-matrix(0,N.time)
posterior.quantile025<-matrix(0,N.time)
posterior.quantile975<-matrix(0,N.time)

for(t in 1:N.time){
  l=data_predict[data_predict$REPORT_YEAR==time_unique[t],][,40:10039]
  l=as.vector(unlist(as.vector(l)))
  posterior.median[t]<-median(l)
  posterior.quantile025[t]<-quantile(l,probs=c(0.025))
  posterior.quantile975[t]<-quantile(l,probs=c(0.975))
}

par(mfrow=c(1,1))

plot(data_predict$REPORT_YEAR,data_predict$HC,xlab="REPORT YEAR",ylab="CORAL COVER")
lines(time_unique,posterior.median,col='red')
lines(time_unique,posterior.quantile025,col='red')
lines(time_unique,posterior.quantile975,col='red')


res.data<-data.frame(cbind(Time=data_predict$REPORT_YEAR,response=data_predict$HC))
by_time <- res.data %>% group_by(Time)

count.lower<-matrix(0,N.time)
count.upper<-matrix(0,N.time)
for(t in 1:N.time){
  l=data_predict[data_predict$REPORT_YEAR==time_unique[t],][,40:10039]
  l=as.vector(unlist(as.vector(l)))
  posterior.quantile025[t]<-quantile(l,probs=c(0.025))
  posterior.quantile975[t]<-quantile(l,probs=c(0.975))
  count.lower[t]<-table(by_time[by_time$Time==time_unique[t],]$response<posterior.quantile025[t])[2]
  count.upper[t]<-table(by_time[by_time$Time==time_unique[t],]$response>posterior.quantile975[t])[2]
}

((sum(count.lower,na.rm = T)+sum(count.upper,na.rm = T))/dim(res.data)[1])*100

#######################################################################################################
out<-matrix(0,dim(para_sim)[2],4)
for(i in 1:dim(para_sim)[2])
{
  t=emp.hpd(para_sim[,i], conf=0.95)
  out[i,]=round(c(mean(para_sim[,i]),sd(para_sim[,i]),t[1],t[2]),4)
}
write.csv(out,"PRIOR_FIXED_EFFECTS_2004.csv")
#######################################################################################################
random_out<-matrix(0,dim(random_sim)[2],4)
for(i in 1:dim(random_sim)[2])
{
  t=emp.hpd(random_sim[,i], conf=0.95)
  random_out[i,]=round(c(mean(random_sim[,i]),sd(random_sim[,i]),t[1],t[2]),4)
}
write.csv(random_out,"RANDOM_MEAN_2004.csv")
#######################################################################################################

#######################################Prior and posterior ############################################
par(mfrow=c(3,3))
plot(density(rnorm(10000,mu_pr[1],sigma_pr[1])),col="red",main="r",lty=1)
lines(density(para_sim[,1]),col="green",lty=2)
legend("topright", inset=.02, legend=c("Prior", "Posterior"),col=c("red", "green"),lty=1:2)

plot(density(rnorm(10000,mu_pr[2],sigma_pr[2])),col="red",main="a",lty=1)
lines(density(para_sim[,2]),col="green",lty=2)
legend("topright", inset=.02, legend=c("Prior", "Posterior"),col=c("red", "green"),lty=1:2)

plot(density(exp(rnorm(10000,mu_pr[3],sigma_pr[3]))),col="red",main="Reef sd",lty=1)
lines(density(exp(para_sim[,3])),col="green",lty=2)
legend("topright", inset=.02, legend=c("Prior", "Posterior"),col=c("red", "green"),lty=1:2)

plot(density(rnorm(10000,mu_pr[4],sigma_pr[4])),col="red",main="CoTS",lty=1)
lines(density(para_sim[,4]),col="green",lty=2)
legend("topright", inset=.02, legend=c("Prior", "Posterior"),col=c("red", "green"),lty=1:2)

plot(density(rnorm(10000,mu_pr[5],sigma_pr[5])),col="red",main="HERB",lty=1)
lines(density(para_sim[,5]),col="green",lty=2)
legend("topright", inset=.02, legend=c("Prior", "Posterior"),col=c("red", "green"),lty=1:2)


plot(density(rnorm(10000,mu_pr[6],sigma_pr[6])),col="red",main="Interaction of CoTS and WQ",lty=1)
lines(density(para_sim[,6]),col="green",lty=2)
legend("topright", inset=.02, legend=c("Prior", "Posterior"),col=c("red", "green"),lty=1:2)


plot(density(rnorm(10000,mu_pr[7],sigma_pr[7])),col="red",main="Interaction of CoTS and ZONE",lty=1)
lines(density(para_sim[,7]),col="green",lty=2)
legend("topright", inset=.02, legend=c("Prior", "Posterior"),col=c("red", "green"),lty=1:2)
#######################################################################################################

#######################################Posterior ############################################
par(mfrow=c(3,3))
plot(density(para_sim[,1]),col="green",lty=2,main="r")
plot(density(para_sim[,2]),col="green",lty=2,main="a")
plot(density(exp(para_sim[,3])),col="green",lty=2,main="Reef sd")
plot(density(para_sim[,4]),col="green",lty=2,main="CoTS")

plot(density(para_sim[,5]),col="green",lty=2,main="HERB")

plot(density(para_sim[,6]),col="green",lty=2,main="Interaction of CoTS and WQ")

plot(density(para_sim[,7]),col="green",lty=2,main="Interaction of CoTS and ZONE")
#######################################################################################################

#######################################################################################################
par(mfrow=c(5,2))
for (i in 1:10){
  plot(density(random_sim[,i]),col="green",lty=2,main=paste("Reef random effects",i))
}
#######################################################################################################