##################################################
## Project: PhD Study 2
## Script purpose: Adaptive design: Long-term trend evaluation when dropping one reef at Stage 3 for optimal vs worsst design comparision
## Date: 15/01/2020
## Author: A.W.L.PUBUDU THILAN
## Description: This is a posterior approximation using Laplace approximation. 
#To handle the missing data within the Laplace approximation, Monte Carlo methods
# were adopted to approximate the full data likelihood based on the current posterior 
# predictive distribution for the missing data. 
##################################################

source('LIB_LOAD.R') #LOAD LIBRARIES
source('stdize.R') #STANDARDIZED COVARIATES
source('Log_likeF.R') # LIKELIHOOD RELATED TO FIXED EFFECT ESTIMATION
source('Log_like2.R') # LIKELIHOOD RELATED TO RANDOM EFFECT ESTIMATION
source('log_posterior2.R')
source('log_posterior3.R')
source('Laplace_approx2.R') # RANDOM EFFECT ESTIMATION
source('log_posteriorF.R') # COMBINDED LIKELIHOOD and PRIOR
source('LP_Approximation.R') # FIXED EFFECT ESTIMATION
source('Random_effect_estimate.R') #RANDOM EFFECT ESTMATION BASED ON ESTIMATED FIXED EFFECTS

seed.val<-20
set.seed(seed.val)

no_samples<-20000 #@@@@@@@@@@@@@@@@@@@@INPUT: NUMBER OF POSTERIOR SIMULATIONS
SAMPLING_YEAR<-2005
N.SIM_MISS=100#@@@@@@@@@@@@@@@@@@@@INPUT:NUMBER OF MISSING SIMULATIONS
MISSING_INDEX_2003=c(25,26,27)#@@@@@@@@@@@@@@@@@@@@INPUT:MISSING_INDEX 2003(Stage 1 worst missing )
MISSING_INDEX_2004=c(25,26,27)#@@@@@@@@@@@@@@@@@@@@INPUT:MISSING_INDEX 2004(Stage 2 worst missing)
MISSING_INDEX_2005=c(25,26,27)#@@@@@@@@@@@@@@@@@@@@INPUT:MISSING_INDEX 2005(Stage 3 worst missing)

###########################@SET FILE NAMES ###################################
v_ut1 <- paste("PRIOR_FIXED_EFFECTS",SAMPLING_YEAR,sep="_")
v_ut2 <- paste("RANDOM_MEAN",SAMPLING_YEAR,sep="_")
v_ut3 <- paste("RANDOM_SIGMA_POST",SAMPLING_YEAR,sep="_")
v_fileName1 <- paste(v_ut1,"RData",sep=".")
v_fileName2 <- paste(v_ut2,"RData",sep=".")
v_fileName3 <- paste(v_ut3,"csv",sep=".")
#############################################################################

GBR_data<-read.csv("GBR_ltmp_Get_Covariate.csv") #@@@@@@@@@@@@@@@@@@@@INPUT: DATA
GBR_data<-GBR_data[GBR_data$A_SECTOR=='CA',] 
GBR_data<-GBR_data[GBR_data$REPORT_YEAR<=SAMPLING_YEAR,] #@@@@@@@@@@@@@@@@@@@@INPUT:SPECIFY SAMPLING YEAR

d<-unique(GBR_data$SITE_INDEX) 
nreefs<-length(unique(GBR_data$REEF_ID))
nsite<-length(d)
n<-dim(GBR_data)[1]
##########################@SET PRIORS ###########################################
prior_fixed_effects<-read.csv("PRIOR_FIXED_EFFECTS_2004.csv") #@@@@@@@@@@@@@@@@@@@@INPUT:FIXED EFFECTS MEAN & SD
random_mean<-t(as.vector(read.csv("RANDOM_MEAN_2004.csv")))#@@@@@@@@@@@@@@@@@@@@INPUT:RANDOM EFFECTS MEANS
random_sigma_post<-as.matrix(read.csv("RANDOM_SIGMA_POST_2004.csv"))#@@@@@@@@@@@@@@@@@@@@INPUT:RANDOM EFFECTS SIGMA
random_sim_missing <- rmvnorm(N.SIM_MISS, random_mean, random_sigma_post)

mu_pr<<-prior_fixed_effects[,1]
sigma_pr<<-prior_fixed_effects[,2]
para<-mu_pr
para2<-random_mean
num_rand<-length(para2)
#################################################################################
Ir_design <- as.matrix(dummy_cols(GBR_data$REEF_ID)[,c(2:(nreefs+1))]) #reef design

HC = round(GBR_data$HC)+1 # Hard coral - out of 200 points
HC1 =round(GBR_data$HC_1) +1 # Lag-1 hard coral

# Covariates
CoTS <- stdize(log(GBR_data$C+1))
BLEACH <- stdize(log(GBR_data$B+1))
HERB <- stdize(log(GBR_data$HERB+1))
ZONE=GBR_data$ZONE

WQ<-rep(0,nreefs) # Index constant reef-scale covariates
for(i in 1:nreefs){
  WQ[i]<-GBR_data[GBR_data$REEF_ID==i,]$PFsum[1]
}
WQ<-stdize(log(WQ))
#################################################################################

#@@@@@@@@@@@@@@INPUT: SET MISSING VALUES @@@@@@@@@@@@@@@@@@@@@
SET_MISSING<-data.frame(cbind(HC,HC1,REPORT_YEAR=GBR_data$REPORT_YEAR,SITE_INDEX=GBR_data$SITE_INDEX,TRANSECT_NO=GBR_data$TRANSECT_NO))
SET_MISSING[SET_MISSING$REPORT_YEAR==SAMPLING_YEAR & SET_MISSING$SITE_INDEX==MISSING_INDEX_2005[1],]$HC<-NA #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==SAMPLING_YEAR & SET_MISSING$SITE_INDEX==MISSING_INDEX_2005[2],]$HC<-NA #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==SAMPLING_YEAR & SET_MISSING$SITE_INDEX==MISSING_INDEX_2005[3],]$HC<-NA #Missing site of the design

# Stage 1 missing filling
Y_impute_2003<-read.csv("Y_impute_wst_2003.csv",head=TRUE,sep=",") #@@@@@@@@@@@@@@@@@@@@INPUT:SIMULATED MISSING VALUES
Y_impute_MEAN_2003<-colMeans(Y_impute_2003[1:N.SIM_MISS,])#@@@@@@@@@@@@@@@@@@@@INPUT:NUMBER OF MISSING SIM USED
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-2) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2003[1],]$HC<-round(Y_impute_MEAN_2003[1:5]) #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-2) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2003[2],]$HC<-round(Y_impute_MEAN_2003[6:10]) #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-2) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2003[3],]$HC<-round(Y_impute_MEAN_2003[11:15]) #Missing site of the design

SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-1) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2003[1],]$HC1<-round(Y_impute_MEAN_2003[1:5]) #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-1) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2003[2],]$HC1<-round(Y_impute_MEAN_2003[6:10]) #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-1) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2003[3],]$HC1<-round(Y_impute_MEAN_2003[11:15]) #Missing site of the design

# Stage 2 missing filling
Y_impute_2004<-read.csv("Y_impute_wst_2004.csv",head=TRUE,sep=",") #@@@@@@@@@@@@@@@@@@@@INPUT:SIMULATED MISSING VALUES
Y_impute_MEAN_2004<-colMeans(Y_impute_2004[1:N.SIM_MISS,])#@@@@@@@@@@@@@@@@@@@@INPUT:NUMBER OF MISSING SIM USED
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-1) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2004[1],]$HC<-round(Y_impute_MEAN_2004[1:5]) #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-1) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2004[2],]$HC<-round(Y_impute_MEAN_2004[6:10]) #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR-1) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2004[3],]$HC<-round(Y_impute_MEAN_2004[11:15]) #Missing site of the design

SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2004[1],]$HC1<-round(Y_impute_MEAN_2004[1:5]) #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2004[2],]$HC1<-round(Y_impute_MEAN_2004[6:10]) #Missing site of the design
SET_MISSING[SET_MISSING$REPORT_YEAR==(SAMPLING_YEAR) & SET_MISSING$SITE_INDEX==MISSING_INDEX_2004[3],]$HC1<-round(Y_impute_MEAN_2004[11:15]) #Missing site of the design

HC<-SET_MISSING$HC
HC1<-SET_MISSING$HC1

Y<-HC
ind <<- which(is.na(Y))
len_miss <- length(ind)

Y_impute_2004 <- matrix(0,N.SIM_MISS,len_miss)
for(i in 1:N.SIM_MISS){  
  para_temp <- rnorm(length(mu_pr),mu_pr,sigma_pr)
  fixed_eff<-para_temp
  zb<-random_sim_missing[i,]
  
  r <- fixed_eff[1]
  a <- fixed_eff[2]
  reef_sd <-exp(fixed_eff[3])
  
  g2 <- fixed_eff[4]
  g7 <- fixed_eff[5]
  g9 <- fixed_eff[6]
  g13 <- fixed_eff[7]
  
  mu <-(1 - a)*log(HC1)+g2*CoTS+g7*HERB+g9*CoTS*(Ir_design %*%matrix(WQ))+g13*CoTS*ZONE+Ir_design %*% zb
  p<-as.matrix(exp(mu)/100)
  if((any(p>1)==TRUE)){
    index=which(p>1)
    p[index,]=rep(0.9999,length(index))
  }
  
  set.seed(seed.val)
  Y_impute_temp <- rbinom(length(Y),100,p)+1
  
  if((any(Y_impute_temp>100)==TRUE)){
    index1=which(Y_impute_temp>100)
    Y_impute_temp[index1]=rep(100,length(index1))
  }
  Y_impute_2004[i,] <- Y_impute_temp[ind]
}
hist(Y_impute_2004[,5]) 

####################################@FIXED EFFECT ESTIMATION ###########################################

####################################@FIXED EFFECT ESTIMATION ###########################################
Sol_Fixed<-LP_Approximation(log_postF,HC,para,para2)
estimated_mean_fixed <- Sol_Fixed$par
Hessian_Fixed<-optimHess(par=estimated_mean_fixed,Y=HC,para2=para2,fn =log_postF)
Sigma_post_Fixed<-solve(Hessian_Fixed)
para_sim <- rmvnorm(no_samples, estimated_mean_fixed, Sigma_post_Fixed)
fixed_mean<-colMeans(para_sim) #mean of fixed effects
#######################################################################################################

####################################@RANDOM EFFECT ESTIMATION ###########################################
Sol_Random<-Random_effect_estimate(para2,fixed_mean,log_post3=log_post3,HC)
estimated_mean_random <-Sol_Random$par
Hessian_Random=optimHess(par=estimated_mean_random,fixed_eff=fixed_mean,fn=log_post3,Y=HC)
Sigma_post_Random<-solve(Hessian_Random)
random_sim <- rmvnorm(no_samples, estimated_mean_random, Sigma_post_Random)
#######################################################################################################

save(list= c("para_sim"),file = v_fileName1)
save(list= c("random_sim"),file = v_fileName2)
save(list= c("Sigma_post_Random"),file = v_fileName3)
save.image("workspace2.RData")
write.csv(Sigma_post_Random, v_fileName3)
#######################################################################################################