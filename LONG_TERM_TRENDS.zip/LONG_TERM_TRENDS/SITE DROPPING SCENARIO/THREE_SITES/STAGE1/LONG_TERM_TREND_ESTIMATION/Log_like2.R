LogLike2 <- function(para2, Y, fixed_eff) {
  
  r <- fixed_eff[1]
  a <- fixed_eff[2]
  reef_sd <-exp(fixed_eff[3])
  
  g2 <- fixed_eff[4]
  g7 <- fixed_eff[5]
  g9 <- fixed_eff[6]
  g13 <- fixed_eff[7]
  
  reef_rand <- matrix(para2, ncol = 1)
  
  mu2 <-(1 - a)*log(HC1)+g2*CoTS+g7*HERB+g9*CoTS*(Ir_design %*%matrix(WQ))+g13*CoTS*ZONE+Ir_design %*% reef_rand
  p2 <- as.matrix(exp(mu2) / 100)
  if ((any(p2 > 1) == TRUE)) {
    index2 = which(p2 > 1)
    p2[index2,] = rep(0.9999, length(index2))
  }
  
  Y_temp<-matrix(rep(Y,N.SIM_MISS),ncol=N.SIM_MISS,nrow=n)
  Y_temp[ind,]<-t(Y_impute2003)
  Log_lkY<-mean(colSums(dbinom(Y_temp,100,p2, log = T)))
  
  log_likelihood <-Log_lkY + sum(dnorm(reef_rand,r,reef_sd, log = T))
  return(log_likelihood)
}

