##################################################
## Project: PhD Study 2
## Script purpose:Utility evaluation when dropping three sites at Stage 1
## Date: 15/01/2020
## Author: A.W.L.PUBUDU THILAN
## Description: This evaluates utility values under dropping three sites. This uses the coordinate-exchange algorithm as described in the manuscript
##################################################

source('LIB_LOAD.R') #LOAD LIBRARIES
source('Log_likeF.R') # LIKELIHOOD RELATED TO FIXED EFFECT ESTIMATION
source('Log_like2.R') # LIKELIHOOD RELATED TO RANDOM EFFECT ESTIMATION
source('log_posterior2.R')
source('Laplace_approx2.R') # RANDOM EFFECT ESTIMATION
source('log_posteriorF.R') # COMBINDED LIKELIHOOD and PRIOR
source('LP_Approximation.R')  # FIXED EFFECT ESTIMATION
source('covariate_generate.R') # SIMULATE COVARIATE DATA
source('trace.R') # CALCULATE TRACE REALTED KLD
source('stdize.R') #STANDARDIZED COVARIATES


seed.val<-20
set.seed(seed.val)

#@@@@@@@@@@@@@@INPUT: PARAMETERS@@@@@@@@@@@@@@@@@@@@@
DESIGN_INDEX<-1#@@@@@@@@@@@@@@@@@@@@INPUT: CHANGE DESIGN INDEX HERE
SAMPLING_YEAR<<-2003#@@@@@@@@@@@@@@@@@@@@INPUT: CHANGE SAMPLYING YEAR HERE
E<-1# independent evaluations
B<-200 #Monte carlo intergration
Total_EB<-E*B
no_samples<-10000

asite<-30
nsite<-27 #@@@@@@@@@@@@@@@@@@@@INPUT:SPECIFY NUMBER OF SITES
nobs<-5 #per site
leny<-nsite*nobs # Total number of samples for next sampling year


set.seed(seed.val)
rand_uni<-matrix(runif(leny*Total_EB),ncol=Total_EB,nrow =leny ) #For deterministic simulation of Y

ST<-asite*Total_EB
set.seed(seed.val)
rand_uni_Cov<-runif(4*ST)
CoTSr<<-matrix(rand_uni_Cov[1:ST],ncol=Total_EB,nrow =asite ) #For deterministic simulation of CoTS
STORMr<<-matrix(rand_uni_Cov[(ST+1):(2*ST)],ncol=Total_EB,nrow =asite)
BLEACHr<<-matrix(rand_uni_Cov[(2*ST+1):(3*ST)],ncol=Total_EB,nrow =asite)
HERBr<<-matrix(rand_uni_Cov[(3*ST+1):(4*ST)],ncol=Total_EB,nrow =asite )

GBR_data<-read.csv("GBR_ltmp_Get_Covariate.csv") #@@@@@@@@@@@@@@@@@@@@INPUT: DATA
GBR_data<-GBR_data[GBR_data$A_SECTOR=='CA',] 
GBR_data<-GBR_data[GBR_data$REPORT_YEAR<=SAMPLING_YEAR,] #@@@@@@@@@@@@@@@@@@@@INPUT:SPECIFY SAMPLING YEAR
nreefs<-length(unique(GBR_data$REEF_ID))#Recode REEF_IDs


######################### START:SIMULATE FIXED EFFECTS ##################################
prior_fixed_effects<-read.csv("PRIOR_FIXED_EFFECTS_2002.csv") #@@@@@@@@@@@@@@@@@@@@INPUT:FIXED EFFECTS MEAN & SD
mu_prior_fixed<-as.vector(unlist(prior_fixed_effects[1]))
Sigma_priorb_fixed<-as.vector(unlist(prior_fixed_effects[2]^2))
Sigma_prior_fixed <-diag(Sigma_priorb_fixed)

iSigma_prior <- solve(Sigma_prior_fixed)
dSigma_prior <- det(Sigma_prior_fixed)
num_par <- length(mu_prior_fixed)

theta_sim_fixed <- matrix(0,nrow=Total_EB,ncol=length(mu_prior_fixed))
set.seed(seed.val)
for (j in 1:length(mu_prior_fixed)){
  theta_sim_fixed[,j] <-rnorm(Total_EB,mu_prior_fixed[j],sqrt(Sigma_priorb_fixed[j]))
}

theta_sim_fixed <- data.frame(theta_sim_fixed)
theta_sim_fixed0 <- as.data.frame(sweep(theta_sim_fixed,2,colMeans(theta_sim_fixed),"-"))  # shift the mean 
C <- chol(nearPD(cov(theta_sim_fixed0))$mat)
set.seed(seed.val)
SN <- matrix(rnorm((Total_EB) * ncol(theta_sim_fixed)), ncol(theta_sim_fixed))#standard normals
X <- t(C) %*% SN
theta_mul_fixed <- data.frame(as.matrix(t(X)))
names(theta_mul_fixed) <- names(theta_sim_fixed)
theta_mul_fixed <- as.data.frame(sweep(theta_mul_fixed,2,colMeans(theta_sim_fixed),"+")) 
theta_sim_all_fixed<-as.matrix(theta_mul_fixed)
######################### END:SIMULATE FIXED EFFECTS ##################################

######################### START:SIMULATE RANDOM EFFECTS ##################################
random_mean<-t(as.vector(read.csv("RANDOM_MEAN_2002.csv")))
random_sigma_post<-as.matrix(read.csv("RANDOM_SIGMA_POST_2002.csv"))
set.seed(seed.val)
theta_sim_all_random <- round(rmvnorm(Total_EB, random_mean, random_sigma_post),digits = 4)

######################### KLD Utility ##################################
kld.utility<-function(d,sim_fixed,sim_random,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr,rand_uni,leny,Sigma_prior_fixed,iSigma_prior,dSigma_prior,num_par){
  kld.post.val=matrix(0,Total_EB)
 
  for (j in 1:Total_EB){
  Covaiate_data<-Get_Covariate(d,seed.val,j,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr) #Simulate covariates 
  nreefs_rem<-length(unique(Covaiate_data$REEF_ID))
  NEW_REEF_ID<-unique(Covaiate_data$REEF_ID)#needs to change here when dropping reefs
  Ir=Covaiate_data[,7]
  Ir_design <<- as.matrix(dummy_cols(Ir)[,c(2:(nreefs_rem+1))])
  ran_design_spatial <<- as.matrix(dummy_cols(Covaiate_data[,1])[,c(2:(nsite+1))])#Create a design matrix for sites
  
  WQ<-rep(0,nreefs_rem) 
  CoTS <<- ifelse(Covaiate_data[,2]-mean(Covaiate_data[,2])<0.00001,Covaiate_data[,2],stdize(Covaiate_data[,2]))
  BLEACH<<-ifelse(Covaiate_data[,4]-mean(Covaiate_data[,4])<0.00001,Covaiate_data[,4],stdize(Covaiate_data[,4]))
  HERB <<- ifelse(Covaiate_data[,5]-mean(Covaiate_data[,5])<0.00001,Covaiate_data[,5],stdize(Covaiate_data[,5]))
  for(i in 1:nreefs_rem){
    WQ[i]<-Covaiate_data[Covaiate_data$REEF_ID==NEW_REEF_ID[i],]$WQ[1]
  }
  WQ<<-WQ
  
  ZONE<<-Covaiate_data[,8]
  HC1<<-round(Covaiate_data[,12]) +1
  
  fixed_eff<-sim_fixed[j,]
  sim_random1<-sim_random[j,]
  
  r <- fixed_eff[1]
  a <- fixed_eff[2]
  reef_sd <-exp(fixed_eff[3])
  
  g2 <- fixed_eff[4]
  g7 <- fixed_eff[5]
  g9 <- fixed_eff[6]
  g13 <- fixed_eff[7]

  zb<-matrix(sim_random1[NEW_REEF_ID],ncol=1)
  
  mu<-(1 - a)*log(HC1)+g2*CoTS+g7*HERB+g9*CoTS*(Ir_design%*%matrix(WQ))+g13*CoTS*ZONE+Ir_design%*%zb
  p<-as.matrix(exp(mu)/100)
  if((any(p>1)==TRUE)){
    index=which(p>1)
    p[index,]=rep(0.9999,length(index))
  }
  
  set.seed(seed.val)
  Y<-qbinom(rand_uni[,j],100,p)
  
  para<-fixed_eff
  para2<-zb
  mu_pr<<-mu_prior_fixed
  sigma_pr<<-as.vector(unlist(prior_fixed_effects[2]))
  kld_out=LP_Approximation(log_postF,Y,para,para2,leny,Sigma_prior_fixed,iSigma_prior,dSigma_prior,num_par)
  kld.post.val[j]=kld_out
  }

  return(kld.post.val)
}

#########################FIND SITES IN THE DESIGN USING COORDINATE-EXCHANGE ALGORITHM#############################
ALL_SITES<-as.vector(seq(1,30,1))

set.seed(seed.val)
RAND_DESIGN<-sample(ALL_SITES,nsite,replace = FALSE, prob = NULL)
RAND_DESIGN

MISSING_SITES<-setdiff(ALL_SITES,RAND_DESIGN)
MISSING_SITES
N.MISS_SITES<-length(MISSING_SITES)

#############################A FUNCTION TO FIND BEST COORDINATE FOR GIVEN LOCATION##########################################
max_site_cal<-function(i,curr_x,curr_u,missig_x,kld.utility,theta_sim_all_fixed,theta_sim_all_random,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr,rand_uni,leny,num_par,N.MISS_SITES)
{
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
print(paste0("Coordinate: ", i))
  prop_x<-curr_x
  max_site<-foreach(k=1:N.MISS_SITES,.combine='cbind',.export = c("prior_fixed_effects","curr_x","curr_u","mu_prior_fixed","Sigma_priorb_fixed","Sigma_prior_fixed","iSigma_prior","dSigma_prior","dSigma_prior","Total_EB","no_samples","asite","nsite","no_samples","seed.val","seed.val","leny","num_par"),.packages = c("matrixcalc","Matrix","mvtnorm","sp","corpcor","fastDummies"))%dopar%
  {
    print("#################################################")
    tem_out<-c(mean(kld.utility(replace(prop_x,i,missig_x[k]),theta_sim_all_fixed,theta_sim_all_random,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr,rand_uni,leny,Sigma_prior_fixed,iSigma_prior,dSigma_prior,num_par),na.rm =T),missig_x[k])
	print(tem_out)
	print("#################################################")
    tem_out
  }
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
  max_site=data.frame(max_site)
  MS=max(data.frame(max_site)[1,])
  if(MS>curr_u){
    site_index<-which(abs((max_site[1,]-MS))<1e-5)
    prop_x[i]<-missig_x[site_index]
	missig_x[site_index]<-curr_x[i]
    curr_x <- prop_x
    curr_u <- MS
  }
  return(list(curr_x,curr_u,missig_x))
}


#############################COORDINATE-EXCHANGE ALGORITHM##########################################

optimal_des<-function(kld.utility,RAND_DESIGN,MISSING_SITES,theta_sim_all_fixed,theta_sim_all_random,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr,rand_uni,leny,num_par,N.MISS_SITES)
{
curr_x<-RAND_DESIGN
missig_x<-MISSING_SITES
curr_u<-mean(kld.utility(curr_x,theta_sim_all_fixed,theta_sim_all_random,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr,rand_uni,leny,Sigma_prior_fixed,iSigma_prior,dSigma_prior,num_par),na.rm=T)
print("Starting random design: ") 
print(curr_x)
print("Missing sites in starting design: ")
print(missig_x)
print(paste0("Initial mean utility value: ", curr_u)) 
  
	for(i in 1:nsite){
      out<-max_site_cal(i,curr_x,curr_u,missig_x,kld.utility,theta_sim_all_fixed,theta_sim_all_random,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr,rand_uni,leny,num_par,N.MISS_SITES)
      curr_x<-out[[1]]
      curr_u<-out[[2]]
	  missig_x<-out[[3]]
      print(paste0("Current ud: ", curr_u))
      print(matrix(c(round(curr_x,0)),byrow=T,nrow=1,ncol=nsite))
	  print(matrix(c(round(missig_x,0)),byrow=T,nrow=1,ncol=N.MISS_SITES))
	  curr_x <- curr_x
      curr_u <- curr_u
	  missig_x<-missig_x
    }
   
  return(list(curr_x,curr_u))
}


# HPC parallel computing set up 

cl <- makeCluster(N.MISS_SITES,outfile="Independent_Run.txt")
clusterEvalQ(cl,.libPaths("/home/n9555293/pubudu/intel_pack"))
registerDoParallel(cl)
getDoParWorkers()

clusterCall(cl, function() { source("LIB_LOAD.R") })
clusterCall(cl, function() { source("Log_likeF.R") })
clusterCall(cl, function() { source("Log_like2.R") })
clusterCall(cl, function() { source("log_posterior2.R") })
clusterCall(cl, function() { source("Laplace_approx2.R") })
clusterCall(cl, function() { source("log_posteriorF.R") })
clusterCall(cl, function() { source("LP_Approximation.R") })
clusterCall(cl, function() { source("covariate_generate.R") })
clusterCall(cl, function() { source("trace.R") })
clusterCall(cl, function() { source("stdize.R") })



optimal_design<-optimal_des(kld.utility,RAND_DESIGN,MISSING_SITES,theta_sim_all_fixed,theta_sim_all_random,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr,rand_uni,leny,num_par,N.MISS_SITES)

v_ut<-"design"
v_fileName <- paste(v_ut,"RData",sep=".")
save(list= c("optimal_design"),file = v_fileName)

stopCluster(cl)








