LogLikeF <- function(Y,para2,fixed_eff,leny){
  log_like_valF<-matrix(rep(0,leny))
  
    post_dist2=Laplace_approx2(fixed_eff=fixed_eff,Y=Y,theta=para2,log_postf1=log_post2,leny=leny)
    U_bar=post_dist2$par
    Hu=post_dist2$hessian
    
  r <- fixed_eff[1]
  a <- fixed_eff[2]
  reef_sd <-exp(fixed_eff[3])
  
  g2 <- fixed_eff[4]
  g7 <- fixed_eff[5]
  g9 <- fixed_eff[6]
  g13 <- fixed_eff[7]
  
  zbF<-as.vector(U_bar)
    
    muF<-(1 - a)*log(HC1)+g2*CoTS+g7*HERB+g9*CoTS*(Ir_design%*%matrix(WQ))+g13*CoTS*ZONE+Ir_design%*%zbF
    pF<-as.matrix(exp(muF)/100)
    if((any(pF>1)==TRUE)){
      indexF=which(pF>1)
      pF[indexF,]=rep(0.9999,length(indexF))
    }

    log_like_valF=dbinom(Y,100,pF, log = T)
    Full_log_likeF <-sum(log_like_valF, na.rm = TRUE)+sum(dnorm(zbF,r,reef_sd,log=T))-round(0.5*log(abs(det(Hu))),digits=4)
    
    if(is.finite(Full_log_likeF)==TRUE) {Full_log_likeF=Full_log_likeF}
    else{Full_log_likeF=-10000000}
    return(Full_log_likeF)

}