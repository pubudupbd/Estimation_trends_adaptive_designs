log_postF <- function(Y,para2,para,leny)
  {
    fixed_eff=as.numeric(para)
    log_prior<-sum(dnorm(fixed_eff,mu_pr,sigma_pr,log=T))
    log.like <-LogLikeF(Y,para2,fixed_eff,leny)
    log_postF=-1*(log.like+log_prior)
    return(log_postF)
}
