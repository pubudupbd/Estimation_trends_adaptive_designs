LogLikeF <- function(Y,para2,fixed_eff){

    post_dist2=Laplace_approx2(fixed_eff=fixed_eff,Y=Y,theta=para2,log_postf1=log_post2)
    U_bar=post_dist2$par
    Hu=optimHess(fixed_eff=fixed_eff,Y=Y,par=U_bar,fn=log_post2)
    reef_rand<-matrix(U_bar,ncol=1)
    
    r<-fixed_eff[1]
    a<-fixed_eff[2]
    reef_sd <-exp(fixed_eff[3])
    
    g2 <- fixed_eff[4]
    g7 <- fixed_eff[5]
    g9 <- fixed_eff[6]
    g13 <- fixed_eff[7]
    
    mu <-(1 - a)*log(HC1)+g2*CoTS+g7*HERB+g9*CoTS*(Ir_design %*%matrix(WQ))+g13*CoTS*ZONE+Ir_design %*% reef_rand
    pF<-as.matrix(exp(mu)/100)
    if((any(pF>1)==TRUE)){
      indexF=which(pF>1)
      pF[indexF,]=rep(0.9999,length(indexF))
    }

      Y_temp<-matrix(rep(Y,N.SIM_MISS),ncol=N.SIM_MISS,nrow=n)
      Y_temp[ind,]<-t(Y_impute2004)
      Log_lkY<-mean(colSums(dbinom(Y_temp,100,pF, log = T)))
    
    log_likelihood <- Log_lkY+sum(dnorm(reef_rand,r,reef_sd,log=T))-0.5*log(abs(det(Hu)))
    return(log_likelihood)

}