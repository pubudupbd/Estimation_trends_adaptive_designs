log_post2 <- function(theta,Y,fixed_eff)
  {
    log.like <- sum(LogLike2(para2=theta,Y=Y,fixed_eff=fixed_eff))
 
    Neg_log_post=-1*(log.like)
    return(Neg_log_post)
  }