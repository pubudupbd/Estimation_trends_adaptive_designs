LogLike2 <- function(para2,Y,fixed_eff){
  log_like_val2<-matrix(rep(0,leny))
  
  r <- fixed_eff[1]
  a <- fixed_eff[2]
  reef_sd <-exp(fixed_eff[3])
  
  g2 <- fixed_eff[4]
  g7 <- fixed_eff[5]
  g9 <- fixed_eff[6]
  g13 <- fixed_eff[7]
  
 zb2<-as.vector(para2) #sptial random effects
  
     mu2<-(1 - a)*log(HC1)+g2*CoTS+g7*HERB+g9*CoTS*(Ir_design%*%matrix(WQ))+g13*CoTS*ZONE+Ir_design%*%zb2
     p2<-as.matrix(exp(mu2)/100)
    if((any(p2>1)==TRUE)){
      index1=which(p2>1)
      p2[index1,]=rep(0.9999,length(index1))
    }
    
    log_like_val2=dbinom(Y,100,p2, log = T)
    Full_log_like2<-sum(log_like_val2, na.rm = TRUE)+sum(dnorm(zb2,r,reef_sd,log=T))
  
    if(is.finite(Full_log_like2)==TRUE) {Full_log_like2=Full_log_like2}
    else{Full_log_like2=-10000000}
    return(Full_log_like2)
}
