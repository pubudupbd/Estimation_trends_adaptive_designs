d<-seq(1,10,1)
all_design<-combn(d, 7)
write.csv(all_design,"design_three_reefs.csv")
