trace <- function(M){
  tr <- sum(diag(M))
  tr
}
