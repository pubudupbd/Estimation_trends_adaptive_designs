##################################################
## Project: PhD Study 2
## Script purpose: Gompertz model (with reef random effects) posterior estimation
## Date: 15/01/2020
## Author: A.W.L.PUBUDU THILAN
## Description: This evaluates the posterior distribution of the Gompertz model at the sampling year of 2002
##################################################

.libPaths("C:/Users/n9592385/OneDrive - Queensland University of Technology/H-Migrated/My PhD work/Rpack")
library("tidyverse")
library("coda")
library("car")# Recoding
library("fastDummies") #create design matrix for random effecst
library("mvtnorm")
library("sp")
library("corpcor")
library("mvtnorm")
library("R2WinBUGS")

source('stdize.R') # TO STANDARDIZE COVARIATES


seed.val<-20
set.seed(seed.val)

##########################@LOADING DATA ###########################################
SAMPLING_YEAR<-2002
GBR_data<-read.csv("GBR_ltmp_Get_Covariate.csv") #@@@@@@@@@@@@@@@@@@@@INPUT: DATA
GBR_data<-GBR_data[GBR_data$A_SECTOR=='CA',] 
GBR_data<-GBR_data[GBR_data$REPORT_YEAR<=SAMPLING_YEAR,] #@@@@@@@@@@@@@@@@@@@@INPUT:SPECIFY SAMPLING YEAR

d<-unique(GBR_data$SITE_INDEX) 
nreefs<-length(unique(GBR_data$REEF_ID))
nsite<-length(d)
n<-dim(GBR_data)[1]

#################################################################################
Ir=GBR_data$REEF_ID

HC = round(GBR_data$HC)+1 # Hard coral - out of 200 points
HC1 =round(GBR_data$HC_1) +1 # Lag-1 hard coral

#STANDARDIZED COVARIATES
CoTS <- stdize(log(GBR_data$C+1))
BLEACH <- stdize(log(GBR_data$B+1))
HERB <- stdize(log(GBR_data$HERB+1))
ZONE=GBR_data$ZONE

WQ<-rep(0,nreefs) # Index constant reef-scale covariates
for(i in 1:nreefs){
  WQ[i]<-GBR_data[GBR_data$REEF_ID==i,]$PFsum[1]
}
WQ<-stdize(log(WQ))
#################################################################################

n.iter=1000000;n.burnin=500000;n.thin = 25
data <- list("nreefs","HC","HC1","n","Ir","CoTS","HERB","WQ","ZONE","Ir")


inits <- function(){
  list(r=0,a=0,log_reef_sd=1,g2=0,g7=0,g9=0,g13=0,reef_rand=rep(0,nreefs))
}


mixedBinomReg.sim <- bugs(data, inits, model.file='GOPMPERTZ_BUG.bug',
                          parameters = c("r","a","log_reef_sd","reef_rand","g2","g7","g9","g13"),
                          n.chains = 1, n.iter = n.iter, n.burnin = n.burnin,
                          n.thin = n.thin,debug = T,DIC = FALSE, digits = 5,
                          codaPkg = F,bugs.directory = "C:/Users/n9592385/OneDrive - Queensland University of Technology/H-Migrated/winbugs14_unrestricted/WinBUGS14")

save.image("thesis_output.RData")

