# Function to standardize covariates
# (See Scaling regression inputs by dividing by two standard deviations for more details)
stdize=function(x){
  mean=mean(x)
  sd=sd(x)
  return((x-mean)/(2*sd)) 
}