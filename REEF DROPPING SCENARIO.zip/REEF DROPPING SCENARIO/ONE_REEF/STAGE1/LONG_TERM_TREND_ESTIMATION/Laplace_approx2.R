Laplace_approx2<- function(Y,theta,log_postf1,fixed_eff)
  {
  lp.approx <-optim(par=theta,Y=Y,fixed_eff=fixed_eff,fn =log_postf1,method="BFGS",hessian = T)
  lp.approx
}

