LP_Approximation <- function(log_postF,Y,para,para2) {
  lowerb=(mu_pr-3*sigma_pr)
  upperb=(mu_pr+3*sigma_pr)
  fun <- nlminb(start=para,Y=Y,para2=para2,objective=log_postF,lower=lowerb,upper=upperb)
  mu_post <- fun$par
  Hes_mat=optimHess(par=mu_post,Y=Y,para2=para2,fn =log_postF)
  
  NON_sig<-0
  if(is.positive.semi.definite(Hes_mat, tol=1e-20)==TRUE)
  {
    Sigma_post<-solve(Hes_mat,tol=1e-20)
    det.out <-0.5*(trace(iSigma_prior%*%Sigma_post) + t(mu_pr-mu_post)%*%iSigma_prior%*%(mu_pr-mu_post)-num_par + log(dSigma_prior)-log(det(Sigma_post)))
    }
  
  else
  {
    print("SIGMA IS NOT POSITIVE SEMI_DEFINITE")
    det.out <- 0.5*(trace(iSigma_prior%*%Sigma_prior_fixed) + t(mu_pr-mu_pr)%*%iSigma_prior%*%(mu_pr-mu_pr)-num_par + log(dSigma_prior)-log(dSigma_prior))
    NON_sig<-1
    
  }
  return(det.out)
}
