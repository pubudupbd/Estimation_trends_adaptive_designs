LP_Approximation <- function(log_postF,Y,para,para2) {
  lowerb=(mu_pr-3*sigma_pr)
  upperb=(mu_pr+3*sigma_pr)
  fun <- nlminb(start=para,Y=Y,para2=para2,objective  =log_postF,lower=lowerb,upper=upperb)
  fun
}
