LP_Approximation <- function(log_postF,Y,para,para2,leny,Sigma_prior_fixed,iSigma_prior,dSigma_prior,num_par) {
  lowerb=(mu_pr-3*sigma_pr)
  upperb=(mu_pr+3*sigma_pr)
  
  fun <- nlminb(start=para,Y=Y,para2=para2,objective=log_postF,lower=lowerb,upper=upperb,leny=leny)
  mu_post <- fun$par
  Hes_mat=optimHess(par=mu_post,Y=Y,para2=para2,fn =log_postF,leny=leny)
  
  if(is.positive.semi.definite(Hes_mat, tol=1e-20)==TRUE)
  {
    Sigma_post<-solve(Hes_mat,tol=1e-20)
    det.out <-0.5*(trace(iSigma_prior%*%Sigma_post) + t(mu_pr-mu_post)%*%iSigma_prior%*%(mu_pr-mu_post)-num_par + log(dSigma_prior)-log(det(Sigma_post)))
    }
  
  else
  {
    det.out <- NA
  }
  return(det.out)
}
