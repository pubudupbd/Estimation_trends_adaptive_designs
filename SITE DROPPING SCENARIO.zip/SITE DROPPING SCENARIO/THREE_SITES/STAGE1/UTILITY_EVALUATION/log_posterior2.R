log_post2 <- function(theta,Y,fixed_eff,leny)
  {
    log.like <- sum(LogLike2(para2=theta,Y=Y,fixed_eff=fixed_eff,leny=leny))
 
    Neg_log_post=-1*(log.like)
    return(Neg_log_post)
  }