log_post3 <- function(theta,Y,fixed_eff,leny)
  {
    #log.prior<- dnorm(fixed_eff[4],mu_pr[4],sigma_pr[4],log=TRUE)
    log.like <- sum(LogLike2(para2=theta,Y=Y,fixed_eff=fixed_eff,leny=leny))
 
    Neg_log_post=-1*(log.like)
    return(Neg_log_post)
  }