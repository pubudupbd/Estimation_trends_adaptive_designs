Get_Covariate=function(site,seed_val,index,SAMPLING_YEAR,STORMr,CoTSr,BLEACHr,HERBr,N.SIM_MISS,MISSING_INDEX)
{
  set.seed(seed_val)
  nsite<-length(site)
  covariate_sub<-matrix(0,nsite,10)
  
  #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  GBR_data<-read.csv("GBR_ltmp_Get_Covariate.csv",head=TRUE,sep=",")
  Y_impute<-read.csv("Y_impute2004.csv",head=TRUE,sep=",") #@@@@@@@@@@@@@@@@@@@@INPUT:SIMULATED MISSING VALUES
  Y_impute_MEAN<-colMeans(Y_impute[1:N.SIM_MISS,])#@@@@@@@@@@@@@@@@@@@@INPUT:NUMBER OF MISSING SIM USED
  
  GBR_data[GBR_data$REPORT_YEAR==SAMPLING_YEAR & GBR_data$SITE_INDEX==MISSING_INDEX[1],]$HC_1<-Y_impute_MEAN[1:5]
  GBR_data[GBR_data$REPORT_YEAR==SAMPLING_YEAR & GBR_data$SITE_INDEX==MISSING_INDEX[2],]$HC_1<-Y_impute_MEAN[6:10]
  GBR_data[GBR_data$REPORT_YEAR==SAMPLING_YEAR & GBR_data$SITE_INDEX==MISSING_INDEX[3],]$HC_1<-Y_impute_MEAN[11:15]
 
  dis_mat<- read.csv(file="distribution_mat_2005_Stage3.csv",head=TRUE,sep=",")
  GBR_data_HC1 <- GBR_data[ which(GBR_data$REPORT_YEAR==SAMPLING_YEAR), ][,c(39,10,29)] #"SITE_INDEX" "TRANSECT_NO" "HC_1" 
  
  
  for(i in 1:nsite){
    t=site[i]
    
  #CoTS
  CoTSrs<-CoTSr[,index][t]
  if(CoTSrs<dis_mat[t,2]){
    covariate_sub[i,1]<-0
  }
  else{covariate_sub[i,1] <-qnorm(CoTSrs,dis_mat[t,3],dis_mat[t,4])}
  
  #STORM
  STORMrs<-STORMr[,index][t]
  if(STORMrs<dis_mat[t,5]){
    covariate_sub[i,2]<-0
  }
  else{covariate_sub[i,2] <-qnorm(STORMrs,dis_mat[t,6],dis_mat[t,7])}
  
  #BLEACH
  BLEACHrs<-BLEACHr[,index][t]
  if(BLEACHrs<dis_mat[t,8]){
    covariate_sub[i,3]<-0
  }
  else{covariate_sub[i,3] <-qnorm(BLEACHrs,dis_mat[t,9],dis_mat[t,10])}
  
  #HERB
  HERBrs<-HERBr[,index][t]
  if(HERBrs<dis_mat[t,11]){
    covariate_sub[i,4]<-0
  }
  else{covariate_sub[i,4] <-qnorm(HERBrs,dis_mat[t,12],dis_mat[t,13])}
  
  #WQ
  covariate_sub[i,5]<-dis_mat$WQ_m[dis_mat$SITE_INDEX==t]# PFsum value at the site
  
  covariate_sub[i,6]<-t
  covariate_sub[i,7]<-GBR_data$REEF_ID[GBR_data$SITE_INDEX==t][1]
  covariate_sub[i,8]<-GBR_data$ZONE[GBR_data$SITE_INDEX==t][1]
  covariate_sub[i,9]<-ifelse(GBR_data$SHELF[GBR_data$SITE_INDEX==t][1]=='M',1,0)
  covariate_sub[i,10]<-ifelse(GBR_data$SHELF[GBR_data$SITE_INDEX==t][1]=='O',1,0)
  
  }
  
  colnames(covariate_sub) <- c("CoTS","STORM","BLEACH","HERB","WQ","SITE_INDEX","REEF_ID","ZONE","Middle","Outer")
  covariate_sub<-merge(x=covariate_sub,y=GBR_data_HC1,by=c('SITE_INDEX'),y.all=T)
  return(covariate_sub)
}


